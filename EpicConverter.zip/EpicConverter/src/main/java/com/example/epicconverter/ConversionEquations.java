package com.example.epicconverter;

public class ConversionEquations extends HelloController {
    static double converted;
    public static Double speedConversions(String argOne, String argTwo) {
        String selections = argOne + "+" + argTwo;
        double textInput = getDoubleFromTextField(HelloController.input);

        switch (selections) {
            case "Feet Per Second+Miles Per Hour":
                converted = fpsToMph(textInput);
                break;
            case "Miles Per Hour+Feet Per Second":
                converted = mphToFps(textInput);
                break;

        }
        return converted;
    }
/*----------------------------SPEED---------------------------------*/
    public static Double fpsToMph (double fps){return fps / 1.467;}
    public static Double mphToFps (double mph){return mph * 1.467;}
}
