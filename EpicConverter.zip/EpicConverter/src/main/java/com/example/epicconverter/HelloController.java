package com.example.epicconverter;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import org.controlsfx.control.SearchableComboBox;

public class HelloController {
    ObservableList<String> options = FXCollections.observableArrayList();
    int unitCode = 0;


    /* TODO:
    Firgure out where the null pointer is coming from on input.
    finish the algorithm
    Fo the writing
     */






    public static Double getDoubleFromTextField(TextField input) {
        String textInput = input.getText();
        return Double.parseDouble(textInput);
    }

    @FXML
    protected void onConvertButtonClick() {
        switch (unitCode) {
            case 1:
                break;
            case 2:
                ConversionEquations.speedConversions(dropdownOne.toString(), dropdownTwo.toString());
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;
            case 6:
                break;
            case 7:
                break;
            default: unitCode = 0;
                break;
        }
        result.setText(Double.toString(ConversionEquations.converted));
    }

    @FXML
    protected void onWeightButtonClick() {
        unitCode = 1;
        options.clear();
        options.add("Tons");
        options.add("Pounds");
        options.add("Ounces");
        options.add("Tonne");
        options.add("Kilograms");
        options.add("Grams");
        options.add("Milligrams");
        dropdownOne.setItems(options);
        dropdownTwo.setItems(options);
    }

    @FXML
    protected void onSpeedButtonClick() {
        unitCode = 2;
        options.clear();
        options.add("Feet Per Second");
        options.add("Miles Per Hour");
        options.add("Meters Per Second");
        options.add("Kilometers Per Hour");
        options.add("Knots");
        dropdownOne.setItems(options);
        dropdownTwo.setItems(options);
    }

    @FXML
    protected void onDistanceButtonClick() {
        unitCode = 3;
        options.clear();
        options.add("Inches");
        options.add("Feet");
        options.add("Yard");
        options.add("Mile");
        options.add("Millimeter");
        options.add("Centimeter");
        options.add("Meter");
        options.add("Kilometer");
        dropdownOne.setItems(options);
        dropdownTwo.setItems(options);
    }

    @FXML
    protected void onVolumeButtonClick() {
        unitCode = 4;
        options.clear();
        options.add("Fluid Ounces");
        options.add("Cup");
        options.add("Pint");
        options.add("Quart");
        options.add("Gallon");
        options.add("Milliliter");
        options.add("Liter");
        options.add("Kiloliter");
        dropdownOne.setItems(options);
        dropdownTwo.setItems(options);
    }

    @FXML
    protected void onAreaButtonClick() {
        unitCode = 5;
        options.clear();
        options.add("Square Feet");
        options.add("Square Mile");
        options.add("Acres");
        options.add("Square Meter");
        options.add("Square Kilometer");
        dropdownOne.setItems(options);
        dropdownTwo.setItems(options);    }

    @FXML
    protected void onTimeButtonClick() {
        unitCode = 6;
        options.clear();
        options.add("Seconds");
        options.add("Minutes");
        options.add("Hours");
        options.add("Days");
        options.add("Years");
        options.add("Decades");
        options.add("Centuries");
        options.add("Millennia");
        dropdownOne.setItems(options);
        dropdownTwo.setItems(options);
    }

    @FXML
    protected void onHeatButtonClick() {
        unitCode = 7;
        options.clear();
        options.add("Fahrenheit");
        options.add("Celsius");
        options.add("Kelvin");
        dropdownOne.setItems(options);
        dropdownTwo.setItems(options);    }

    @FXML
    public SearchableComboBox<String> dropdownOne ;

    @FXML
    public SearchableComboBox<String> dropdownTwo ;

    @FXML
    public TextField result;

    @FXML
    public static TextField input;
}
