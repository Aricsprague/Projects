import org.junit.Test;
import static org.junit.Assert.*;
public class MainTest {

    @Test
    public void testPlayAgain() {
        Main pAgain = new Main();
        //assertEquals();
    }
}