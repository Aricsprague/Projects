public class HarderNumber {
    int min = 1;
    int max = 50;
    int genNumber = (int) (Math.random() * (max - min + 1) + min);
}
