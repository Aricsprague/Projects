import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        new Gameplay().playGame(new Scanner(System.in));
    }
}