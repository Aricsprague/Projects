/*
1) What is a superclass?
2) What is a subclass?
3) What is method overloading?
4) What is method overriding?
5) What is the difference between overloading and overriding?
*/


//5) What is the difference between overloading and overriding?
/* Method overloading is the process of defining multiple methods with the same name but different parameters.
* Method overriding is the process of using a single method but changing the implementation of that method.*/

public class Main {
    String objective = "Reference the other classes for examples :)";
}