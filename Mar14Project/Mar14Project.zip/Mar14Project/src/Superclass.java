// 1) What Is a superclass?
//subclass (child) - the class that inherits from another class
//superclass (parent) - the class being inherited from

public class Superclass { // It's names superclass but think of it as an inventory of ice cream flavors
        protected String flavor = "Vanilla";        // ice cream attribute
        public void exclaim() {                    // ice cream method
            System.out.println("So Delicious!");
        }
}
