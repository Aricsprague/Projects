// Base or Super Class
class Employee {
    int salary = 60000;
}

// Inherited or Sub Class
class Developer extends Employee {
    int benefits = 10000;
}

// Driver Class
class Inheritance {
    public static void main(String args[])
    {
        Developer dave = new Developer();
        System.out.println("Salary : " + dave.salary
                + "\nBenefits : " + dave.benefits);
    }
}